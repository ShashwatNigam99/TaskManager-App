from pinboard_app import app
app.run(debug=True)
