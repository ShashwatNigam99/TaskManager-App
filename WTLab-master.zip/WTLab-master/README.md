# WTLab
Flask based trello clone for my lab. 

Instructions to run :<br>
1. Clone the repo and cd into it.<br>
2. Create a virtualenv<br>
```virtualenv venv --python=python2.7```<br>
3. Activate the virtualenv<br>
```source venv/bin/activate```<br>
4. Install requirements<br>
```pip install requirements.txt```<br>
  // might be a -r tag not sure.<br>
5. Run the server by running the runserver.py script<br>
