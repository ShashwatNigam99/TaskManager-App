import os

basedir = os.path.abspath(os.path.dirname(__file__))

SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'app.sqlite')

SQLALCHEMY_MIGRATE_REPO = os.path.join(basedir, 'db_repository')

MONGODB_HOST = 'localhost'
MONGODB_PORT = 27017
